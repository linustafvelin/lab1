public interface Movable {
    void move();
    void turnLeft();
    void turnRight();


}
