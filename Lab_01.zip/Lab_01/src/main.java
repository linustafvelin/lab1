public class main {
    public static void main(String[] args) {
        //Vehicle volvo = new Volvo240(10, 10);
        //volvo.move();
    }
}
